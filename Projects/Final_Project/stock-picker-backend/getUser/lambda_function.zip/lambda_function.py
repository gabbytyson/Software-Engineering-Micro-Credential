import json
import boto3
import psycopg2

conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="adminpassword",
    host="finance-db.coolhiu6ujmg.us-east-2.rds.amazonaws.com",
    port='5432'
)

def lambda_handler(event, context):
    try:
        cur = conn.cursor()
        cur.execute("""SELECT * FROM user_account""")
        query_results = cur.fetchall()
        print(query_results)
    except Exception as e:
        print("Database connection failed due to {}".format(e))